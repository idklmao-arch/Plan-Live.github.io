# Week Planner — with accounts

Anyone can sign up with an email and password. Each person's classes, shifts, tasks and activities are private to them and sync across all their devices. The screenshot reader runs on a small server function so your Anthropic API key never reaches the browser.

**What's in this folder**

| File | What it is |
|---|---|
| `index.html` | The whole app (host it anywhere that serves static files) |
| `supabase/schema.sql` | Database tables + privacy rules (run once) |
| `supabase/functions/read-schedule/` | Reads shifts from screenshots using Claude |
| `supabase/functions/delete-account/` | Lets a user delete their own account |

**Cost:** Supabase and most static hosts have free tiers. The only usage-based cost is the Anthropic API, used when someone reads screenshots (capped per user per day, see step 6).

---

## Setup (about 30 minutes)

### 1. Create the backend
1. Sign up at supabase.com → **New project**. Save the database password somewhere safe.
2. Open **SQL Editor → New query**, paste all of `supabase/schema.sql`, click **Run**.

### 2. Connect the app
1. In Supabase: **Project Settings → API**. Copy the **Project URL** and the **anon public** key.
2. Open `index.html`, find `SUPABASE_URL` and `SUPABASE_ANON_KEY` near the top of the script, and paste them in.
   The anon key is meant to be public. Privacy comes from the row-level-security rules in `schema.sql`.
   **Never** paste the `service_role` key into `index.html`.

### 3. Host the page
Upload `index.html` to any static host: Netlify Drop (drag and drop), Cloudflare Pages, Vercel, or GitHub Pages. Note the address you get, e.g. `https://my-planner.netlify.app`.

### 4. Tell Supabase where the app lives
**Authentication → URL Configuration**
- **Site URL:** your address from step 3
- **Redirect URLs:** add the same address (needed for confirmation and password-reset links)

### 5. Make sign-up emails reliable
Supabase's built-in email sender is limited to a handful of emails per hour. That's fine for testing and not for a public launch.
**Authentication → SMTP Settings** → connect a sender such as Resend, Postmark or SendGrid.
Keep **Confirm email** switched on (it is by default). It stops fake sign-ups and protects your API budget.

### 6. Deploy the server functions (screenshot reading and account deletion)
Install the Supabase CLI (supabase.com/docs/guides/cli), then in this folder:

```
supabase login
supabase link --project-ref YOUR_PROJECT_REF        # the code in your project URL
supabase secrets set ANTHROPIC_API_KEY=sk-ant-...   # from console.anthropic.com
supabase secrets set DAILY_SCAN_LIMIT=10            # optional: screenshot reads per user per day
supabase secrets set ALLOWED_ORIGIN=https://my-planner.netlify.app   # optional but recommended
supabase functions deploy read-schedule
supabase functions deploy delete-account
```
In the Anthropic console, **set a monthly spend limit** on the API key.

If you skip this step, everything works except reading screenshots and deleting accounts. The .ics/.vcs import and manual entry are unaffected.

### 7. Test it
1. Open your site → **Create an account** → confirm via the email → sign in.
2. Add a class, then open the site on your phone, sign in, and check that it appears.
3. Work tab → add a picture of a schedule → **Read shifts**.
4. Try **Forgot password?** end to end.

---

## Before sharing it widely
- **Privacy policy and terms.** You'll be storing people's email addresses and schedules, and sending their screenshots to Anthropic's API to be read. Say so plainly, and don't store the screenshots (this app doesn't).
- **Backups.** Supabase's free tier has no automatic backups of your data. Consider upgrading or exporting periodically.
- **Free-tier pausing.** Free Supabase projects pause after about a week of no activity.
- **Abuse.** Daily scan limits are per account. Email confirmation and your Anthropic spend limit are your backstops.

## How it works
- Sign-up/login: Supabase Auth (email + password, confirmation emails, password reset).
- Data: one row per user in `planners` (a JSON copy of their planner). Rules let each person read and write only their own row.
- Sync: edits save after about a second; other devices update live, and refresh when you return to the tab. If two devices edit at the same time, the latest edit wins.
- Sign out clears the local copy (when fully synced), so nothing stays behind on shared computers.

## Not included yet
Social sign-in (Google/Apple), two-factor authentication, sharing a schedule with friends, and email notifications. All are doable on this foundation.
